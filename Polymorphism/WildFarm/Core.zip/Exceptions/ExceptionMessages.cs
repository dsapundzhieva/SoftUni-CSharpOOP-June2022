﻿namespace WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public const string InvalidTypeOfFood = "{0} does not eat {1}!";
    }
}
