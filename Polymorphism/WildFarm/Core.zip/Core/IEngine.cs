﻿namespace WildFarm.Core
{
    public interface IEngine
    {
        void Start();
    }
}
